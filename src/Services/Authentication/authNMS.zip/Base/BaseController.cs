﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using $safeprojectname$.Interface;
using $safeprojectname$.Utils;

namespace $safeprojectname$.Base
{
    [Route("api/[controller]")]
    [ApiController]
    public abstract class BaseController<TModel, TReadDto, TCreateDto, TUpdateDto> : ControllerBase 
        where TModel: class
        where TReadDto: BaseDto, new()
        where TCreateDto: class
        where TUpdateDto: class
    {
        private readonly IContextRepo<TModel> _opRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<TModel> _logger;

        public BaseController(ILogger<TModel> logger, IContextRepo<TModel> opRepository, IMapper mapper)
        {
            _opRepository = opRepository;
            _mapper = mapper;
            _logger = logger;
        }

        // GET api/Model All Model
        //[Authorize]
        [HttpGet]
        public virtual ActionResult<IEnumerable<TReadDto>> GetAll()
        {
            _logger.LogInformation(LogEvents.ListResourses, "Listing resourses ");
            var opItems = _opRepository.GetAll();
            if(opItems.Count() == 0) _logger.LogInformation(LogEvents.ListResourses, "No resourses");
            // make the repo get all usertypes to map it with Model 
            //Return a Maped the op to opDTO 
            return Ok(_mapper.Map<IEnumerable<TReadDto>>(opItems));
        }
        // GET api/Model/{id} One use with id
        //[Authorize]
        [HttpGet("{id}", Name = "[controller]/GetById")]
        public virtual ActionResult<TReadDto> GetById(int id)
        {
            _logger.LogInformation(LogEvents.GetResourse, "Getting resourse {Id}", id);
            var opModel = _opRepository.GetById(id);
            // if found return a user Dto
            if (opModel == null)
            {
                _logger.LogWarning(LogEvents.GetResourseNotFound, "Get({Id}) NOT FOUND", id);
                return NotFound();
            }
            // make the repo get user usertypes to map it with user 
            return Ok(_mapper.Map<TReadDto>(opModel));
        }

        // POST api/Model
        [Authorize]
        [HttpPost]
        public virtual ActionResult<TReadDto> Create(TCreateDto CreateDto)
        {
            _logger.LogInformation(LogEvents.CreateResourse, "Creating new resourse");
            // Map user dto to use then create it in Db and save
            var opModel = _mapper.Map<TModel>(CreateDto);
            var result  = _opRepository.Create(opModel);
            if (!result.Success) return BadRequest(result.Message);
            _opRepository.SaveChanges();

            // need to send new URI with response, so map user to TReadDto response 
            // then pass the id of it to nameof GetGroupById and pass it to response as well
            var ReadDto = _mapper.Map<TReadDto>(result.Model);
            var route = this.ControllerContext.ActionDescriptor.ControllerName + "/GetById";
            return CreatedAtRoute(route, new { ReadDto.Id }, ReadDto);
        }
        // PUT api/Model/{id}
        [Authorize]
        [HttpPut("{id}")]
        public virtual ActionResult Update(int id, TUpdateDto UpdateDto)
        {
            _logger.LogInformation(LogEvents.UpdateResourse, "Updating resourse {Id}", id);
            var opModel = _opRepository.GetById(id);
            if (opModel == null)
            {
                _logger.LogWarning(LogEvents.GetResourseNotFound, "Get({Id}) NOT FOUND", id);
                return NotFound();
            }

            // Map user dto to user which will update Db then save
            _mapper.Map(UpdateDto, opModel);
            var result = _opRepository.Update(opModel);
            if (!result.Success) return BadRequest(result.Message);
            _opRepository.SaveChanges();

            return NoContent();
        }

        // PATCH api/s/{id}
        [Authorize]
        [HttpPatch("{id}")]
        public virtual ActionResult PartialUpdate(int id, JsonPatchDocument<TUpdateDto> patchDoc)
        {
            _logger.LogInformation(LogEvents.UpdateResourse, "Updating (patching) resourse {Id}", id);
            var opModel = _opRepository.GetById(id);
            if (opModel == null)
            {
                _logger.LogWarning(LogEvents.GetResourseNotFound, "Get({Id}) NOT FOUND", id);
                return NotFound();
            }

            // mapp TModel to user dto then try to apple the patch doc to it.
            var opToPatch = _mapper.Map<TUpdateDto>(opModel);
            patchDoc.ApplyTo(opToPatch, ModelState);
            if (!TryValidateModel(opModel))
            {
                return ValidationProblem(ModelState);
            }

            // Map patched user to user which will update Db then save
            _mapper.Map(opToPatch, opModel);
            var result = _opRepository.Update(opModel);
            if (!result.Success) return BadRequest(result.Message);
            _opRepository.SaveChanges();

            return NoContent();
        }

        // DELETE api/s/{id}
        [Authorize]
        [HttpDelete("{id}")]
        public virtual ActionResult Delete(int id)
        {
            _logger.LogInformation(LogEvents.DeleteResourse, "Deleting resourse {Id}", id);
            var opModel = _opRepository.GetById(id);
            if (opModel == null)
            {
                _logger.LogWarning(LogEvents.GetResourseNotFound, "Get({Id}) NOT FOUND", id);
                return NotFound();
            }

            var result = _opRepository.Delete(opModel);
            if (!result.Success) return BadRequest(result.Message);
            _opRepository.SaveChanges();

            return NoContent();
        }
    }
}
