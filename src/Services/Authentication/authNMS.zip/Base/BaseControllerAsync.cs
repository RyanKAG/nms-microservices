﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using $safeprojectname$.Interface;
using $safeprojectname$.Utils;

namespace $safeprojectname$.Base
{
    [Route("api/[controller]")]
    [ApiController]
    public abstract class BaseControllerAsync<TModel, TReadDto, TCreateDto, TUpdateDto> : ControllerBase
        where TModel : class
        where TReadDto : BaseDto, new()
        where TCreateDto : class
        where TUpdateDto : class
    {
        private readonly IContextRepo<TModel> _opRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<TModel> _logger;

        public BaseControllerAsync(ILogger<TModel> logger, IContextRepo<TModel> opRepository, IMapper mapper)
        {
            _opRepository = opRepository;
            _mapper = mapper;
            _logger = logger;
        }

        // GET api/Model All Model
        //[Authorize]
        [HttpGet]
        public virtual async Task<ActionResult<IEnumerable<TReadDto>>> GetAll()
        {
            _logger.LogInformation(LogEvents.ListResourses, "Listing resourses ");
            var opItems = await _opRepository.GetAllAsync();
            if (opItems.Count() == 0) _logger.LogInformation(LogEvents.ListResourses, "No resourses");
            // make the repo get all usertypes to map it with Model 
            //Return a Maped the op to opDTO 
            return Ok(_mapper.Map<IEnumerable<TReadDto>>(opItems));
        }
        // GET api/Model/{id} One use with id
        //[Authorize]
        [HttpGet("{id}", Name = "[controller]/GetById")]
        public virtual async Task<ActionResult<TReadDto>> GetById(int id)
        {
            _logger.LogInformation(LogEvents.GetResourse, "Getting resourse {Id}", id);
            var opModel = await _opRepository.GetByIdAsync(id);
            // if found return a user Dto
            if (opModel == null)
            {
                _logger.LogWarning(LogEvents.GetResourseNotFound, "Get({Id}) NOT FOUND", id);
                return NotFound();
            }
            // make the repo get user usertypes to map it with user 
            return Ok(_mapper.Map<TReadDto>(opModel));
        }

        // POST api/Model
        [Authorize]
        [HttpPost]
        public virtual async Task <ActionResult<TReadDto>> Create(TCreateDto CreateDto)
        {
            _logger.LogInformation(LogEvents.CreateResourse, "Creating new resourse");
            // Map user dto to use then create it in Db and save
            var opModel = _mapper.Map<TModel>(CreateDto);
            var result = await _opRepository.CreateAsync(opModel);
            if (!result.Success) return BadRequest(result.Message);
            await _opRepository.SaveChangesAsync();

            // need to send new URI with response, so map user to TReadDto response 
            // then pass the id of it to nameof GetGroupById and pass it to response as well
            var ReadDto = _mapper.Map<TReadDto>(result.Model);
            // the route for the resource using the get by id action
            var route = this.ControllerContext.ActionDescriptor.ControllerName + "/GetById";
            return CreatedAtRoute(route, new { ReadDto.Id }, ReadDto);
        }
        // PUT api/Model/{id}
        [Authorize]
        [HttpPut("{id}")]
        public virtual async Task<ActionResult> Update(int id, TUpdateDto UpdateDto)
        {
            _logger.LogInformation(LogEvents.UpdateResourse, "Updating resourse {Id}", id);
            var opModel = await  _opRepository.GetByIdAsync(id);
            if (opModel == null)
            {
                _logger.LogWarning(LogEvents.GetResourseNotFound, "Get({Id}) NOT FOUND", id);
                return NotFound();
            }

            // Map user dto to user which will update Db then save
            _mapper.Map(UpdateDto, opModel);
            var result = await _opRepository.UpdateAsync(opModel);
            if (!result.Success) return BadRequest(result.Message);
            await _opRepository.SaveChangesAsync();

            return NoContent();
        }

        // PATCH api/s/{id}
        [Authorize]
        [HttpPatch("{id}")]
        public virtual async Task<ActionResult> PartialUpdate(int id, JsonPatchDocument<TUpdateDto> patchDoc)
        {
            _logger.LogInformation(LogEvents.UpdateResourse, "Updating (patching) resourse {Id}", id);
            var opModel = await _opRepository.GetByIdAsync(id);
            if (opModel == null)
            {
                _logger.LogWarning(LogEvents.GetResourseNotFound, "Get({Id}) NOT FOUND", id);
                return NotFound();
            }

            // mapp TModel to user dto then try to apple the patch doc to it.
            var opToPatch = _mapper.Map<TUpdateDto>(opModel);
            patchDoc.ApplyTo(opToPatch, ModelState);
            if (!TryValidateModel(opModel))
            {
                return ValidationProblem(ModelState);
            }

            // Map patched user to user which will update Db then save
            _mapper.Map(opToPatch, opModel);
            var result = await _opRepository.UpdateAsync(opModel);
            if (!result.Success) return BadRequest(result.Message);
            await _opRepository.SaveChangesAsync();

            return NoContent();
        }

        // DELETE api/s/{id}
        [Authorize]
        [HttpDelete("{id}")]
        public virtual async Task<ActionResult> Delete(int id)
        {
            _logger.LogInformation(LogEvents.DeleteResourse, "Deleting resourse {Id}", id);
            var opModel = await _opRepository.GetByIdAsync(id);
            if (opModel == null)
            {
                _logger.LogWarning(LogEvents.GetResourseNotFound, "Get({Id}) NOT FOUND", id);
                return NotFound();
            }

            var result = await _opRepository.DeleteAsync(opModel);
            if (!result.Success) return BadRequest(result.Message);
            await _opRepository.SaveChangesAsync();

            return NoContent();
        }
    }
}
