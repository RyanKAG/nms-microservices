﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using $safeprojectname$.Interface;
using $safeprojectname$.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace $safeprojectname$.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signinManager;
        private readonly IAuthRepo _authRepo;

        public UsersController(UserManager<User> userManager, SignInManager<User> signInManager, IAuthRepo authRepo)
        {
            _userManager = userManager;
            _signinManager = signInManager;
            _authRepo = authRepo;
        }

        // POST api/<ValuesController>
        [HttpPost("register")]
        public void Register(UserRecord register)
        {
            var user = new User
            {
                UserName = register.Username,
                Email = "",
                Firstname = "Abdullah",
                Lastname = "Hazmi"
            };

            var result = _userManager.CreateAsync(user, register.Password).Result;

            if (result.Succeeded)
            {

            }

        }
        // POST api/<ValuesController>
        [HttpPost("login")]
        public async Task<ActionResult<string>> Login(UserRecord login)
        {
            var user = _userManager.FindByNameAsync(login.Username).Result;
            if(user != null)
            {
                //sign in 
                var result = _signinManager.PasswordSignInAsync(user, login.Password, false, false).Result;
                
                if (result.Succeeded)
                {
                    var token = await _authRepo.GenerateToken(user);
                    return Ok(token);
                } 
                else
                {
                    return Unauthorized();
                }

            }
            return NotFound();
            

        }

        public record UserRecord(string Username, string Password);
    }
}
