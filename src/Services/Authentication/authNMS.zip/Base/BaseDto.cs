﻿using System;

namespace $safeprojectname$.Base
{
    public abstract class BaseDto
    {
        public abstract int Id { get; set; }
    } 
    public abstract class BaseDtoGuid
    {
        public abstract Guid Id { get; set; }
    }
}
