﻿using System.Threading.Tasks;
using $safeprojectname$.Models;

namespace $safeprojectname$.Interface
{
    public interface IAuthRepo
    {
        Task<string> GenerateToken(User user);
    }
}
