﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using $safeprojectname$.Dtos;

namespace $safeprojectname$.Interface
{
    public interface IContextRepo<TModel> 
        where TModel: class
    {
        Task<bool> SaveChangesAsync();
        bool SaveChanges();
        Task<IEnumerable<TModel>> GetAllAsync();
        IEnumerable<TModel> GetAll();
        Task<TModel> GetByIdAsync(int id);
        TModel GetById(int id);
        Task<TModel> GetByIdAsync(Guid id);
        TModel GetById(Guid id);
        Task<Response<TModel>> CreateAsync(TModel model);
        Response<TModel> Create(TModel model);
        Task<Response<TModel>> UpdateAsync(TModel model);
        Response<TModel> Update(TModel model);
        Task<Response<TModel>> DeleteAsync(TModel model);
        Response<TModel> Delete(TModel model);
        Task<int> GetCountAsync();
        int GetCount();
    }    
}
