﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Dtos;
using $safeprojectname$.Interface;
using $safeprojectname$.Models;

namespace $safeprojectname$.Base
{
    public abstract class BaseRepo<TModel> : IContextRepo<TModel> 
        where TModel: class
    {
        protected readonly AppDbContext _context;
        private readonly DbSet<TModel> _table;

        public BaseRepo(AppDbContext context)
        {
            _context = context;
            _table = _context.Set<TModel>();
        }
        public virtual Response<TModel> Create(TModel model)
        {
            /*if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }
            _table.Add(model);*/

            try
            {
                _table.Add(model);
                return new Response<TModel>(model);
            }
            catch (Exception ex)
            {
                // Do some logging stuff
                return new Response<TModel>($"An error occurred when saving: {ex.Message}");
            }
        }

        public virtual async Task<Response<TModel>> CreateAsync(TModel model)
        {
           /* if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }
            await _table.AddAsync(model);
            await Task.CompletedTask;*/

            try
            {
                await _table.AddAsync(model);
                return new Response<TModel>(model);
            }
            catch (Exception ex)
            {
                // Do some logging stuff
                return new Response<TModel>($"An error occurred when saving: {ex.Message}");
            }
        }

        public virtual Response<TModel> Delete(TModel model)
        {
            /* if (model == null)
            {
                 throw new ArgumentNullException(nameof(model));
             }
             _table.Remove(model);*/
            try
            {
                _table.Remove(model);
                return new Response<TModel>(model);
            }
            catch (Exception ex)
            {
                // Do some logging stuff
                return new Response<TModel>($"An error occurred when deleting: {ex.Message}");
            }
        }

        public virtual async Task<Response<TModel>> DeleteAsync(TModel model)
        {
            /* if (model == null)
             {
                 throw new ArgumentNullException(nameof(model));
             }
             _table.Remove(model);
             await Task.CompletedTask;*/
            try
            {
                _table.Remove(model);
                await Task.CompletedTask;
                return new Response<TModel>(model);
            }
            catch (Exception ex)
            {
                // Do some logging stuff
                return new Response<TModel>($"An error occurred when deleting: {ex.Message}");
            }
        }

        public virtual IEnumerable<TModel> GetAll()
        {
            return _table.ToList();
        }

        public virtual async Task<IEnumerable<TModel>> GetAllAsync()
        {
            return await _table.ToListAsync();
        }

        public virtual TModel GetById(int id)
        {
            return _table.Find(id);
        }

        public TModel GetById(Guid id)
        {
            return _table.Find(id);
        }

        public virtual async Task<TModel> GetByIdAsync(int id)
        {
            return await _table.FindAsync(id);
        }

        public virtual async Task<TModel> GetByIdAsync(Guid id)
        {
            return await _table.FindAsync(id);
        }

        public virtual int GetCount()
        {
            return _table.ToList().Count;
        }

        public virtual async Task<int> GetCountAsync()
        {
            var list = await _table.ToListAsync();
            return list.Count;
        }

        public virtual bool SaveChanges()
        {
            //if saved return true
            return _context.SaveChanges() >= 0;
        }

        public virtual async Task<bool> SaveChangesAsync()
        {
            //if saved return true
            return await _context.SaveChangesAsync() >= 0;
        }

        public virtual Response<TModel> Update(TModel model)
        {
            try
            {
                return new Response<TModel>(model);
            }
            catch (Exception ex)
            {
                // Do some logging stuff
                return new Response<TModel>($"An error occurred when updating: {ex.Message}");
            }
        }

        public virtual async Task<Response<TModel>> UpdateAsync(TModel model)
        {
            try
            {
                await Task.CompletedTask;
                return new Response<TModel>(model);
            }
            catch (Exception ex)
            {
                // Do some logging stuff
                return new Response<TModel>($"An error occurred when updating: {ex.Message}");
            }
        }
    }
}
